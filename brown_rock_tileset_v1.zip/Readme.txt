Brown Rock Tileset - Version 1
by kodzegura from Mushra Games ヾ(⌐■_■)ノ

Features (free):
- Brown Rock Area: various tiles, pillars, bridges, and stairs.
- Green Area: grass tiles, trees, and bushes.
- Additional rural environment including 3 houses.
- Red Rock Area: available on Patreon and Ko-fi for free (links below)

Added in V2 (paid): https://mushragames.itch.io/brown-rock-tileset
- Roads & Rock Textures
- Animated water tiles
- Fixes & Tweaks

Bonus free assets on our patreon/kofi pages (donation isn't required, but highly appreciated):
https://ko-fi.com/mushragames
https://www.patreon.com/MushraGames

Need custom art or music for your project?

Contact:
Email for contact/paypal: mushragames@gmail.com.
Twitter/X: @mushra_games
Instagram: @mushragames
All socials & stores: https://mushragames.carrd.co/

Also, tell about your game in the comments/DMs, we'd be happy to play it!
Thanks for downloading our assets, best of luck with your project!
